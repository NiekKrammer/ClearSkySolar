<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240320112757 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE `order` ADD huisnummer VARCHAR(30) NOT NULL, ADD postcode VARCHAR(50) NOT NULL, CHANGE date date DATETIME NOT NULL, CHANGE address straatnaam VARCHAR(255) NOT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE `order` DROP huisnummer, DROP postcode, CHANGE date date DATETIME DEFAULT NULL, CHANGE straatnaam address VARCHAR(255) NOT NULL');
    }
}
